sap.ui.define(["sap/ui/core/Control"], function(Control) {
	"use strict";
	return Control.extend("app.control.GoogleMap", {
		"metadata": {
			"properties": {
					address: "string",
			lat: "string",
			long: "string"
			},
		
		},
		init: function() {
			this._html= new sap.ui.core.HTML({content: "<div style='height:100%; width:100%;' id ='"+ this.getId()+"-map'></div>"});
		},
		renderer: function(oRm, oControl) {
		oRm.write("<div style='height:440px; width;75%; margin:20px;'  ");
			oRm.writeControlData(oControl);
			oRm.write(">");
			oRm.renderControl(oControl._html);
			oRm.write("</div>");
			
		},
	onAfterRendering : function()
		{
		var options ={
			Zoom:2,
			center: new google.maps.LatLng(32.88,13.180161)
			};
			var _map = new google.maps.Map(jQuery.sap.domById(this.getId()+"-map"), options);
			
			var geocoder = new google.maps.Geocoder();
			geocoder.geocode({ 'address':this.getAddress()}, function(results, status)
			{
				if ( status === google.maps.GeocoderStatus.OK)
				{
					var triangleCoords = [
						
						new google.maps.LatLng(37.630768, -119.032631),
						new google.maps.LatLng(52.452381, -1.743507),
						new google.maps.LatLng(-20.917574, 142.702789)
						
						
						];
						
						var len = triangleCoords.length;
						for( var i = 0; i<len;i++)
						{
							var marker  = new google.maps.Marker({
								map: _map,
								position: results[i].geomatry.location
								
							});
						}
				}
				else
				{
					console.log("not successful");
				}
			}
		
			
			)
			
		}
	});
});