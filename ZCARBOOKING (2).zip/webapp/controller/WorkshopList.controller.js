sap.ui.define([
	"app/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"app/model/formatter",
	"sap/m/MessagePopover",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/core/format/DateFormat",
	"sap/m/Dialog",
	"sap/ui/core/message/Message",
	"sap/ui/core/MessageType",
	"sap/ui/Device",
], function(BaseController, JSONModel, formatter, MessagePopover, MessageBox, MessageToast, DateFormat, Dialog, Message, MessageType,
	Device) {
	"use strict";

	return BaseController.extend("app.controller.WorkshopList", {

		onInit: function() {

			this.getRouter().getRoute("workshop").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function() {

			var oModel = new JSONModel(jQuery.sap.getModulePath("sap.ui.demo.mock", "/countries.json"));

			this.setModel(oModel, "Country");
			var oModel2 = new JSONModel(jQuery.sap.getModulePath("sap.ui.demo.mock", "/states.json"));

			this.setModel(oModel2, "State");
			var oModel3 = new JSONModel(jQuery.sap.getModulePath("sap.ui.demo.mock", "/cities.json"));

			this.setModel(oModel3, "City");
		},
		
		onSelectionChangeountry: function(oEvent)
		{
			
			
		},
			/**
		 * interface to set the client model based on parameters passed
		 * @param {string} sModelName name of model that will be created
		 * @param {String} sEntityName name of set which will contain the dataset provided
		 * @param {object} oData      dataset that needs to be passed to client model
		 * @private
		 */
		_setClientModel: function(sModelName, sEntityName, oData) {
			var oClientModel = this.getModel(sModelName),
				bModelExists = typeof oClientModel === "undefined" ? false : true;
			//If Model doesn't exist on view level then create new one and add data
			if (!bModelExists) {
				oClientModel = new JSONModel();
			}
			//Set data to Model and appropiate property(entityset)
			if (oData.results) {
				oClientModel.setProperty(sEntityName, oData.results);
			} else {
				oClientModel.setProperty(sEntityName, oData);
			}
			//If model model exists on view level then refresh or set model to view
			if (!bModelExists) {
				this.setModel(oClientModel, sModelName);
			}
		},

	});

});