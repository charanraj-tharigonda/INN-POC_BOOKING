/*global history */
sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/ui/core/routing/History",
				 "sap/ui/core/Fragment",
               "sap/ui/core/message/Message",
               "sap/ui/core/MessageType"
	], function (Controller, History,Fragment,Message,MessageType) {
		"use strict";

		return Controller.extend("app.controller.BaseController", {
			/**
			 * Convenience method for accessing the router in every controller of the application.
			 * @public
			 * @returns {sap.ui.core.routing.Router} the router for this component
			 */
			getRouter : function () {
				return this.getOwnerComponent().getRouter();
			},

			/**
			 * Convenience method for getting the view model by name in every controller of the application.
			 * @public
			 * @param {string} sName the model name
			 * @returns {sap.ui.model.Model} the model instance
			 */
			getModel : function (sName) {
				return this.getView().getModel(sName);
			},

			/**
			 * Convenience method for setting the view model in every controller of the application.
			 * @public
			 * @param {sap.ui.model.Model} oModel the model instance
			 * @param {string} sName the model name
			 * @returns {sap.ui.mvc.View} the view instance
			 */
			setModel : function (oModel, sName) {
				return this.getView().setModel(oModel, sName);
			},
			
					      /**
         * Function returns the instance of the message manager 
         * @returns {object} message manager object reference
         * @public
         */
        getMessageManager: function(){
            return sap.ui.getCore().getMessageManager();
        },
        
        /**
         * Function adds the  message to the Message Processor Model based on the Target Path this removes existing message of that particular bind path
         * @param {sTarget} bind path of the control
         * @param {sMessage} message text
         * @param {sLongText} Long description text
         * @param {oMessageProcessor} message processor model
         * @public
         */
        addMessages: function(sTarget, sMessage, sLongText, oMessageProcessor){
        	var oMessageManager = this.getMessageManager();
        	//Remove existing messages for that control
        	this.removeMessage(sTarget,oMessageProcessor);
        	//Add a new message
            oMessageManager.addMessages(
            	    new Message({
            	    	message: sMessage,
            	    	description: sLongText,
            	        type: MessageType.Error,
            	        target: sTarget,
            	        processor: oMessageProcessor
            	     })
            	);
        },
        
         /**
         * Function removes the a message from the Message Processor Model based on the Target Path
         * @param {sTarget} bind path of the control
         * @param {oMessageProcessor} message processor model
         * @public
         */
        removeMessage: function(sTarget,oMessageProcessor){
        	var oMessageManager = this.getMessageManager();
        	oMessageManager.removeMessages(oMessageProcessor.getMessagesByPath(sTarget)); 
        },
        
        /**
         * function returns the instance of the message Processor model 
         * @returns {object} Message manager model object reference
         * @public
         */
        getMessageModel: function(){
        	return this.getMessageManager().getMessageModel();
        },
        
        	/* This method can be called to determine whether the sapUiSizeCompact or sapUiSizeCozy
		 * design mode class should be set, which influences the size appearance of some controls.
		 * @public
		 * @return {string} css class, either 'sapUiSizeCompact' or 'sapUiSizeCozy' - or an empty string if no css class should be set
		 */
		getContentDensityClass: function() {
			return this.getOwnerComponent().getContentDensityClass();
		},
        
           /**
         * function get the message processor as a parameter and register to the Message Processor
         * function get the Message Processor model and set to the view message model
         * @param {oMessageProcessor} message processor model
         * @public
         */
        initializeMessageManager: function(oMessageProcessor){
        	var oMessageManager = this.getMessageManager();
            oMessageManager.registerMessageProcessor(oMessageProcessor);
            this.getView().setModel(this.getMessageModel(),"message");
        },
			/*This method can be called to get reference of the busy dialog control inside the BusyDialog Fragment*/
		getBusyDialog: function() {
			if (!this._oBusyDialog) {
				this._oBusyDialog = sap.ui.xmlfragment(this._getBusyDialogId(),
					"app.fragments.BusyDialog",
					this);
				this.getView().addDependent(this._oBusyDialog);
			//	jQuery.sap.syncStyleClass(this.getContentDensityClass(), this.getView(), this._oBusyDialog);
			}
			return this._oBusyDialog;
		},
        
        	/*This method can be called to get the ID of the BusyDialog Fragment*/
		_getBusyDialogId: function() {
			return this.createId("ticketCreateBusyDialog");
		},
			/*This method can be called to get reference of a particular control inside a fragment*/
		getFragmentControl: function(sFragId, sControlId) {
			var sId = Fragment.createId(sFragId, sControlId);
			return this.byId(sId);
		},

			/**
			 * Convenience method for getting the resource bundle.
			 * @public
			 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
			 */
			getResourceBundle : function () {
				return this.getOwnerComponent().getModel("i18n").getResourceBundle();
			},

			/**
			 * Event handler for navigating back.
			 * It there is a history entry we go one step back in the browser history
			 * If not, it will replace the current entry of the browser history with the master route.
			 * @public
			 */
			onNavBack : function() {
				var sPreviousHash = History.getInstance().getPreviousHash();

					if (sPreviousHash !== undefined) {
					history.go(-1);
				} else {
					this.getRouter().navTo("master", {}, true);
				}
			}

		});

	}
);