/* eslint-disable*/
/*global location*/
sap.ui.define([
	"app/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"app/model/formatter",
	"sap/m/MessagePopover",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/core/format/DateFormat",
	"sap/m/Dialog",
	"sap/ui/core/message/Message",
	"sap/ui/core/MessageType",
], function(BaseController, JSONModel, formatter, MessagePopover, MessageBox, MessageToast, DateFormat, Dialog, Message, MessageType) {
	"use strict";

	return BaseController.extend("app.controller.AddCar", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf app.view.AddCar
		 */
		onInit: function() {

			this.getRouter().getRoute("addcar").attachPatternMatched(this._onObjectMatched, this);

		},

		/**
		 * interface to set the client model based on parameters passed
		 * @param {string} sModelName name of model that will be created
		 * @param {String} sEntityName name of set which will contain the dataset provided
		 * @param {object} oData      dataset that needs to be passed to client model
		 * @private
		 */
		_setClientModel: function(sModelName, sEntityName, oData) {
			var oClientModel = this.getModel(sModelName),
				bModelExists = typeof oClientModel === "undefined" ? false : true;
			//If Model doesn't exist on view level then create new one and add data
			if (!bModelExists) {
				oClientModel = new JSONModel();
			}
			//Set data to Model and appropiate property(entityset)
			if (oData.results) {
				oClientModel.setProperty(sEntityName, oData.results);
			} else {
				oClientModel.setProperty(sEntityName, oData);
			}
			//If model model exists on view level then refresh or set model to view
			if (!bModelExists) {
				this.setModel(oClientModel, sModelName);
			}
		},
		onSave: function(oEvent) {

			var oMake = this.byId("comboType").getProperty("value");
			var oModel = this.byId("comboType1").getProperty("value");
			var oYear = this.byId("comboType2").getProperty("value");
			var oReg = this.byId("idReg").getValue();
			var oKM = this.byId("idKM").getValue();
			var oMilage = this.byId("idCarMillage").getValue();
			var oAvgMilage = this.byId("idCarAvgMillage").getValue();
			var random = this._randomXToY();

			// var oEntry = {
			// 	ZvehicalId: random,
			// 	ZvehicalName: oMake,
			// 	ZvehicalModel: oModel,
			// 	ZvehicalYear: oYear,
			// 	ZvehicalReg: oReg,
			// 	ZvehicalMlg: oMilage,
			// 	ZvhicalAvgmlg: oAvgMilage,
			// 	ZvehicalFueltype: "Petrol"

			// }

			var oEntry = {
				ZvehicalId: 179,
				ZvehicalName: "Jaug",
				ZvehicalModel: "fff45678",
				ZvehicalYear: "2018",
				ZvehicalReg: "12w",
				ZvehicalMlg: "11kmpl",
				ZvhicalAvgmlg: "10kmpl",
				ZvehicalFueltype: "Petrol"

			};
			this.getBusyDialog();
			this.getFragmentControl(this._getBusyDialogId(), "ticketCreateBusyDialog").open();
			this.getModel().create("/VehicalSet", oEntry, {

				success: jQuery.proxy(this._fnHandleSuccessVehicalAdded, this),
				error: jQuery.proxy(this._fnHandleErrorVehicalAdded, this)
			});

		},
		/**
		 * Event handler when a message popop over is pressed
		 * @param {sap.ui.base.Event} oEvent the message pop over
		 * @public
		 */
		onMessagePopoverPress: function(oEvent) {

			if (!this.oErrorPopover) {
				this.oErrorPopover = sap.ui.xmlfragment("app.fragments.MessagePopover", this);
			}
			this.getView().addDependent(this.oErrorPopover);
			if (!this.oErrorPopover.isOpen()) {
				this.oErrorPopover.openBy(oEvent.getSource());
			} else {
				this.oErrorPopover.close();
			}
		},
		/**
		 * This method return the id of Busy Dialog
		 * @private
		 */
		_getBusyDialog: function() {
			return this.byId("gdBusyDialog");
		},
		_fnHandleSuccessVehicalAdded: function(oData, oResponce) {
			this.getModel("data").setProperty("/goBack", true);

			if (oResponce.statusCode <= "200" || oResponce.statusCode >= "299") {
				this.getModel("data").setProperty("/goBack", false);
					this.getFragmentControl(this._getBusyDialogId(), "ticketCreateBusyDialog").close();
			}
			if (this.getModel("data").getProperty("/goBack")) {
				this.getFragmentControl(this._getBusyDialogId(), "ticketCreateBusyDialog").close();
				MessageToast.show(this.getResourceBundle().getText("CAR Added successfully"), {
					duration: 5000,
					animationDuration: 9000
				});
				this.getModel().refresh();
				this._fnClearViewState();
				this.onNavBack();

			}

		},

		onNavBack: function() {
			this.getRouter().navTo("object");
		},
		/**
		 * clears all the view global data and Header UI controls state
		 * @private
		 */
		_fnClearViewState: function() {

			this._bIsEvent = false;
			this._bIsDirty = false;
			this._worklistFlag = false;
			this._displayFlag = false;
			this._dateflag = true;
			this.byId("idReg").setValue("");
			this.byId("idKM").setValue("");
			this.byId("idCarMillage").setValue("");
			this.byId("idCarAvgMillage").setValue("");
			this.byId("idReg").setValueState("None");
			this.byId("idKM").setValueState("None");
			this.byId("idCarMillage").setValueState("None");
			this.byId("idCarAvgMillage").setValueState("None");
			//this.getMessageManager().removeAllMessages();

		},
		_fnHandleErrorVehicalAdded: function(oError, oResponce) {

		},

		_randomXToY: function() {
			var minVal = 0,
				maxVal = 254;
			var randVal = minVal + (Math.random() * (maxVal - minVal));
			return Math.round(randVal);
		},
		onSelectionChange: function(oEvent) {
			var oTktQuantity = [];
			var ocarModelName = {
				Name: "a"
			};
			var sPath = oEvent.getParameter("selectedItem").getBindingContext("carData").getPath().split("/")[2];
			var oCarModel = this.getModel("carData").getData().CarCollection[sPath].models;
			for (var i = 0; i < oCarModel.length; i++) {
				ocarModelName = {
					Name: oCarModel[i]
				};
				var oTicketEntry = Object.assign({}, ocarModelName);
				oTktQuantity[i] = oTicketEntry;
			}
			this._setClientModel("CarModels", "/Models", oTktQuantity);
		},
		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			var oModel = new JSONModel(jQuery.sap.getModulePath("sap.ui.demo.mock", "/Cars.json"));

			this.setModel(oModel, "carData");
			var oModelData = new JSONModel({});
			this.setModel(oModelData, "data");
			this.initializeMessageManager(this.getModel("data"));
		}

	});

});