sap.ui.define([
		"app/model/GroupSortState",
		"sap/ui/model/json/JSONModel"
	], function (GroupSortState, JSONModel) {
	"use strict";

	QUnit.module("GroupSortState - grouping and sorting", {
		beforeEach: function () {
			this.oModel = new JSONModel({});
			// System under test
			this.oGroupSortState = new GroupSortState(this.oModel, function() {});
		}
	});

	QUnit.test("Should always return a sorter when sorting", function (assert) {
		// Act + Assert
		assert.strictEqual(this.oGroupSortState.sort("ZvehicalId").length, 1, "The sorting by ZvehicalId returned a sorter");
		assert.strictEqual(this.oGroupSortState.sort("ZvehicalName").length, 1, "The sorting by ZvehicalName returned a sorter");
	});

	QUnit.test("Should return a grouper when grouping", function (assert) {
		// Act + Assert
		assert.strictEqual(this.oGroupSortState.group("ZvehicalId").length, 1, "The group by ZvehicalId returned a sorter");
		assert.strictEqual(this.oGroupSortState.group("None").length, 0, "The sorting by None returned no sorter");
	});


	QUnit.test("Should set the sorting to ZvehicalId if the user groupes by ZvehicalId", function (assert) {
		// Act + Assert
		this.oGroupSortState.group("ZvehicalId");
		assert.strictEqual(this.oModel.getProperty("/sortBy"), "ZvehicalId", "The sorting is the same as the grouping");
	});

	QUnit.test("Should set the grouping to None if the user sorts by ZvehicalName and there was a grouping before", function (assert) {
		// Arrange
		this.oModel.setProperty("/groupBy", "ZvehicalId");

		this.oGroupSortState.sort("ZvehicalName");

		// Assert
		assert.strictEqual(this.oModel.getProperty("/groupBy"), "None", "The grouping got reset");
	});
});